﻿using BLL.DTO;
using BLL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace wep_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TripController : ControllerBase
    {
        ITripBLL bll;

        public TripController(ITripBLL bll)
        {
            this.bll = bll;
        }
        [HttpGet("GetAllTrips")]
        public ActionResult<List<TripDTO>> getAllTrips()
        {
            return Ok(bll.getAll());
        }
        [HttpGet("GetTripById/{id}")]
        public ActionResult<TripDTO> getTripById(int id)
        {
            return Ok(bll.getById(id));
        }
        [HttpGet("GetInvitesToTripById/{id}")]
        public ActionResult<List<List<BookingPlaceDTO>>> GetInvitesToTripById(int id) 
        {
            return Ok(bll.getInvitesToTrip(id)); 
        }
        [HttpPost("AddTrip")]
        public ActionResult<int> AddTrip(TripDTO trip)
        {
            return Ok(bll.addTrip(trip));
        }
        
        [HttpPut("UpdateTrip")]
        public ActionResult<bool> UpdateTrip(TripDTO trip)
        {
            return Ok(bll.updateTrip(trip));
        }
        [HttpDelete("DeleteTrip/{id}")]
        public ActionResult<bool> DeleteTrip(int id)
        {
            return Ok(bll.deleteTrip(id));
        }
    }
}
