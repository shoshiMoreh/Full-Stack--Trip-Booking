﻿using BLL.DTO;
using BLL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace wep_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IUserBLL bll;

        public UserController(IUserBLL bll)
        {
            this.bll = bll;
        }
        [HttpGet("GetAllUsers")]
        public ActionResult<List<UserDTO>> GetAllUsers()
        {
            return Ok(bll.getAll());
        }
        [HttpGet("GetUserByMailAndPassword/{mail}/{password}")]
        public ActionResult<UserDTO> GetUserByMailAndPassword(string mail, string password)
        {
            return Ok(bll.getUserByMailAndPassword(mail, password));
        }
        [HttpPost("AddUser")]
        public ActionResult<int> addUser(UserDTO user)
        {
            return Ok(bll.addUser(user));
        }
        [HttpPut("UpdateUser")]
        public ActionResult<bool> updateUser(UserDTO user)
        {
            return Ok(bll.updateUser(user));
        }
        [HttpDelete("DeleteUser/{id}")]
        public ActionResult<bool> DeleteUser(int id)
        {
            return Ok(bll.deleteUser(id));
        }
        [HttpGet("GetAllTripToUser/{id}")]
        public ActionResult GetAllTripToUser(int id)
        {
            return Ok(bll.getAllTrip(id));
        }
    }
}
