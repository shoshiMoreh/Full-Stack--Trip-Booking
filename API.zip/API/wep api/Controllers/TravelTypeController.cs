﻿using BLL.DTO;
using BLL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;

namespace wep_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TravelTypeController : ControllerBase
    {
        ITravelTypeBLL bll;

        public TravelTypeController(ITravelTypeBLL bll)
        {
            this.bll = bll;

        } 
        [HttpGet("GetAllTavelType")]
        public ActionResult<List<TravelTypeDTO>> GetAllTavelType()
        {
            return Ok(bll.getAll());
        }
    }
}
