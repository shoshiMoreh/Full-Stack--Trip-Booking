﻿using BLL.DTO;
using BLL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace wep_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingPlaceController : ControllerBase
    {
        IBookingPlaceBLL bll;

        public BookingPlaceController(IBookingPlaceBLL bll)
        {
            this.bll = bll;
        }
        [HttpPost("AddInviteToTrip")]
        public ActionResult<int> AddInviteToTrip(BookingPlaceDTO bp)
        {
            return Ok(bll.addBookingPlace(bp));
        }
        [HttpDelete("DeleteBookingPlace")]
        public ActionResult<bool> DeleteBookingPlace(int id)
        {
            return Ok(bll.deleteBookingPlace(id));
        }
        [HttpGet("GetAllInviteToTrip/{id}")]
        public ActionResult<List<BookingPlaceDTO>> GetAllInviteToTrip(int id)
        {
            return Ok(bll.getAllToTrip(id));
        }
    }
}
