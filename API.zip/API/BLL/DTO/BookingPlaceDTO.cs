﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTO
{
    public class BookingPlaceDTO
    {
        public int BookingCode { get; set; }

        public int? UserCode { get; set; }

        public DateTime? BookingDate { get; set; }

        public TimeSpan? BookingTime { get; set; }

        public int? TripCode { get; set; }

        public int? NumberOfPlaces { get; set; }
        public string? FullName { get; set; }
        public string? TripDestination { get; set; }
        public DateTime? Date { get; set; }
    }
}
