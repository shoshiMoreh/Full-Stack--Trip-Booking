﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTO
{
    public class TravelTypeDTO
    {
        public int TypeCode { get; set; }

        public string? TypeName { get; set; }
    }
}
