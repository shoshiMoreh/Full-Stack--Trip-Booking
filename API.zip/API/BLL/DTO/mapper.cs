﻿using AutoMapper;
using DAL.data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTO
{
    public class mapper:Profile
    {
        public mapper() 
        {
            CreateMap<BookingPlace, BookingPlaceDTO>()
                .ForMember(dest => dest.FullName, opt => opt.MapFrom(src => src.UserCodeNavigation.Name + " " + src.UserCodeNavigation.Family))
                .ForMember(dest => dest.TripDestination, opt => opt.MapFrom(src => src.TripCodeNavigation.TripDestination))
                .ForMember(dest => dest.Date, opt => opt.MapFrom(src => src.TripCodeNavigation.Date));
            CreateMap<BookingPlaceDTO,BookingPlace>();
            CreateMap<TravelType,TravelTypeDTO>();
            CreateMap<TravelTypeDTO,TravelType>();
            CreateMap<Trip, TripDTO>()
                .ForMember(dest => dest.TypeName, opt => opt.MapFrom(src => src.TypeCodeNavigation.TypeName))
                .ForMember(dest => dest.FirstAidCertificate, opt => opt.MapFrom(src => src.BookingPlaces.FirstOrDefault(x => x.UserCodeNavigation.FirstAidCertificate == true) == null));
            CreateMap<TripDTO,Trip>();
            CreateMap<User,UserDTO>();
            CreateMap<UserDTO,User>();

        }
    }
}
