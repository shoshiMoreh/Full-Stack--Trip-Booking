﻿using AutoMapper;
using BLL.DTO;
using BLL.inter;
using DAL.data;
using DAL.inter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.func
{
    public class TripBLL:ITripBLL
    {
        ITripDAL idal;
        IMapper imapper;
        IBookingPlaceDAL ibp;
        public TripBLL(ITripDAL idal, IBookingPlaceDAL ibp)
        {
            this.idal = idal;
            this.ibp = ibp;
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<mapper>();
            });
            imapper = config.CreateMapper();
        }
        public List<TripDTO> getAll()
        {
            return imapper.Map<List<Trip>, List<TripDTO>>(idal.getAll());
        }
        public TripDTO getById(int id)
        {
            return imapper.Map<Trip, TripDTO>(idal.getById(id));
        }
        public int addTrip(TripDTO trip)
        {
            if(idal.getAll().FirstOrDefault(x=> x.TripCode == trip.TripCode)==null)
                return idal.addTrip(imapper.Map<TripDTO, Trip>(trip));
            return -1;
        }
        public bool updateTrip(TripDTO trip)
        {
            if (idal.getAll().FirstOrDefault(x => x.TripCode == trip.TripCode) != null)
                if (trip.Date.Value > DateTime.Now)
                    return idal.updateTrip(imapper.Map<TripDTO,Trip>(trip));
            return false;
        }
        public List<BookingPlaceDTO> getInvitesToTrip(int id)
        {
            return imapper.Map<List<BookingPlace>, List<BookingPlaceDTO>>(ibp.getAll().Where(x=> x.TripCode==id).ToList());
        }
        public bool deleteTrip(int id)
        {
            return idal.deleteTrip(id);
        }
    }
}
