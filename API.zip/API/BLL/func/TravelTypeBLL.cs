﻿using AutoMapper;
using BLL.DTO;
using BLL.inter;
using DAL.data;
using DAL.inter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.func
{
    public class TravelTypeBLL:ITravelTypeBLL
    {
        ITravelTypeDAL idal;
        IMapper imapper;
        public TravelTypeBLL(ITravelTypeDAL idal)
        {
            this.idal = idal;
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<mapper>();
            });
            imapper = config.CreateMapper();
        }
        public List<TravelTypeDTO> getAll()
        {
            return imapper.Map<List<TravelType>, List<TravelTypeDTO>>(idal.getAll());
        }
        public int addTravelType(TravelTypeDTO type)
        {
            if (idal.getById(type.TypeCode) == null)
                return idal.addTravelType(imapper.Map<TravelTypeDTO, TravelType>(type));
            return -1;
        }
        public bool deleteTravelType(int id)
        {
            if(idal.getById(id)!=null)
                return idal.deleteTravelType(id);
            else return false;
        }
    }
}
