﻿using AutoMapper;
using BLL.DTO;
using BLL.inter;
using DAL.data;
using DAL.inter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.func
{
    public class UserBLL:IUserBLL
    {
        IUserDAL idal;
        IBookingPlaceDAL ibp;
        ITripDAL itd;
        IMapper imapper;
        public UserBLL(IUserDAL idal, IBookingPlaceDAL ibp, ITripDAL itd)
        {
            this.idal = idal;
            this.ibp = ibp;
            this.itd = itd;
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<mapper>();
            });
            imapper = config.CreateMapper();
        }
        public List<UserDTO> getAll() 
        {
            return imapper.Map<List<User>,List<UserDTO>>(idal.getAll());    
        }
        public UserDTO getUserByMailAndPassword(string mail, string password)
        {
            return imapper.Map<User, UserDTO>(idal.getByMailAndPassword(mail, password));
        }
        public int addUser(UserDTO user)
        {
            if(idal.getByMailAndPassword(user.Email, user.LoginPassword)==null)
                return idal.addUser(imapper.Map<UserDTO, User>((user)));
            return -1;
        }
        public bool updateUser(UserDTO user)
        {
            if(idal.getByMailAndPassword(user.Email, user.LoginPassword) != null)
                return idal.updateUser(imapper.Map<UserDTO, User>((user)));
            return false;
        }
        public bool deleteUser(int id)
        {
            if (ibp.getAll().FirstOrDefault(x => x.UserCode == id) == null)
                return idal.deleteUser(id);
            return false;
        }
        public List<TripDTO> getAllTrip(int id)
        {
            List<BookingPlaceDTO> b= imapper.Map<List<BookingPlace>,List<BookingPlaceDTO>>(ibp.getAll().Where(x=> x.UserCode==id).ToList());
            List<TripDTO> t = new List<TripDTO>();
            foreach (BookingPlaceDTO i in b)
            {
                t.Add(imapper.Map<Trip, TripDTO>(itd.getAll().FirstOrDefault(x => x.TripCode == i.TripCode)));
            }
            return t;
        }
    }
}
