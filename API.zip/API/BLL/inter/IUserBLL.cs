﻿using BLL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.inter
{
    public interface IUserBLL
    {
        public List<UserDTO> getAll();
        public UserDTO getUserByMailAndPassword(string mail, string password);
        public int addUser(UserDTO user);
        public bool updateUser(UserDTO user);
        public bool deleteUser(int id);
        public List<TripDTO> getAllTrip(int id);



    }
}
