﻿using BLL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.inter
{
    public interface ITripBLL
    {
        public List<TripDTO> getAll();
        public TripDTO getById(int id);
        public int addTrip(TripDTO trip);
        public bool updateTrip(TripDTO trip);
        public List<BookingPlaceDTO> getInvitesToTrip(int id);
        public bool deleteTrip(int id);


    }
}
