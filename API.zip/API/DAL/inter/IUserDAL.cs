﻿using DAL.data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.inter
{
    public interface IUserDAL
    {
        public List<User> getAll();
        public User getByMailAndPassword(string mail, string password);
        public int addUser(User user);
        public bool deleteUser(int id);
        public bool updateUser(User t);

    }
}
