﻿using DAL.data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.inter
{
    public interface ITravelTypeDAL
    {
        public List<TravelType> getAll();
        public TravelType getById(int id);
        public int addTravelType(TravelType travelT);
        public bool deleteTravelType(int id);

    }
}
