﻿using DAL.data;
using DAL.inter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.func
{
    public class UserDAL:IUserDAL
    {
        TravelsContext db;
        public UserDAL(TravelsContext db)
        {
            this.db = db;
        }
        public List<User> getAll()
        {
            return db.Users
                .Include(x=> x.BookingPlaces)
                .ThenInclude(x=> x.TripCodeNavigation)
                .ToList();
        }
        public User getByMailAndPassword(string mail, string password)
        {
            return db.Users.FirstOrDefault(x => x.Email == mail && x.LoginPassword == password);
        }
        public int addUser(User user)
        {
            db.Users.Add(user);
            db.SaveChanges();
            return user.UserCode;
        }
        public bool deleteUser(int id)
        {
            try
            {
                db.Users.Remove(db.Users.FirstOrDefault(x=> x.UserCode == id));
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool updateUser(User t)
        {
            User u = db.Users.FirstOrDefault(x=> x.UserCode == t.UserCode);
            if(u != null)
            {
                u.Name = t.Name;
                u.Family = t.Family;
                u.Phone = t.Phone;
                u.Email = t.Email;
                u.LoginPassword = t.LoginPassword;
                u.FirstAidCertificate = t.FirstAidCertificate;
                db.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
