﻿using DAL.data;
using DAL.inter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.func
{
    public class BookingPlaceDAL:IBookingPlaceDAL
    {
        TravelsContext db;
        public BookingPlaceDAL(TravelsContext db)
        {
            this.db = db;
        }
        public List<BookingPlace> getAll() 
        {
            return db.BookingPlaces
                .Include(x=> x.TripCodeNavigation)
                .ThenInclude(x=> x.TypeCodeNavigation)
                .Include(x=> x.UserCodeNavigation)
                .ThenInclude(x=> x.BookingPlaces)
                .ToList();  
        }
        public BookingPlace getById(int id)
        {
            return db.BookingPlaces.FirstOrDefault(x => x.BookingCode == id);
        }
        public int addBookingPlace(BookingPlace bp)
        {
            db.BookingPlaces.Add(bp);
            db.SaveChanges();
            return bp.BookingCode;
        }
        public bool deleteBookingPlace(int id)
        {
            try
            {
                db.BookingPlaces.Remove(getById(id));
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
