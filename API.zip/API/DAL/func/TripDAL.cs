﻿using DAL.data;
using DAL.inter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.func
{
    public class TripDAL:ITripDAL
    {
        TravelsContext db;
        public TripDAL(TravelsContext db) 
        {
            this.db = db;
        }
        public List<Trip> getAll() 
        {
            return db.Trips
                .Include(x=> x.BookingPlaces)
                .ThenInclude(x=> x.UserCodeNavigation)
                .Include(x=> x.TypeCodeNavigation)
                .ToList();
        }
        public Trip getById(int id)
        {
            return db.Trips.FirstOrDefault(x => x.TripCode == id);
        }
        public int addTrip(Trip trip)
        {
            db.Trips.Add(trip);
            db.SaveChanges();
            return trip.TripCode;
        }
        public bool deleteTrip(int id)
        {
            try
            {
                db.Trips.Remove(getById(id));
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool updateTrip(Trip t) 
        {
            Trip t1 = db.Trips.FirstOrDefault(x => x.TripCode == t.TripCode);
            if (t1 != null)
            {
                t1.TripDestination = t.TripDestination;
                t1.Price = t.Price;
                t1.TripDurationHours = t.TripDurationHours;
                t1.TypeCode = t.TypeCode;
                t1.Date = t.Date;
                //t1.DepartureTime = t.DepartureTime;
                t1.NumberOfAvailablePlaces=t.NumberOfAvailablePlaces;
                t1.Photo=t.Photo;
                db.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
